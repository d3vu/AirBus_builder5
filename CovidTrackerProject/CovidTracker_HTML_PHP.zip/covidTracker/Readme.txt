Readme file for HMTL_CSS_JS_PHP project


Requirments:
1. php
2. mysql
3. Xamp server

Steps to run project:
1. Unzip the file you will get a folder covidTracker
2. Copy that folder 
3. Paste that folder in your xamp htdoc (C:\xampp\htdocs)
4. Start your xamp server
5. Run your code